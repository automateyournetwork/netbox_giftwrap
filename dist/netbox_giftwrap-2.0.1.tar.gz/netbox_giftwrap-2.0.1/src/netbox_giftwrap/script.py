from .netbox_giftwrap import cli
def run():
    cli()